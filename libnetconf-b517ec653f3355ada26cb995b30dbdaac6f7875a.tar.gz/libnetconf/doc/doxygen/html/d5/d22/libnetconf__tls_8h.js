var libnetconf__tls_8h =
[
    [ "nc_tls_destroy", "d5/d22/libnetconf__tls_8h.html#gacf3aed5cccac55d0548f46761707ece9", null ],
    [ "nc_tls_init", "d5/d22/libnetconf__tls_8h.html#ga9e011091a1e6ce205e58f4d9677a7e17", null ]
];