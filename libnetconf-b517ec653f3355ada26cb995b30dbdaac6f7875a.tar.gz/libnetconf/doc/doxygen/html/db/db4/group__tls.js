var group__tls =
[
    [ "nc_tls_destroy", "db/db4/group__tls.html#gacf3aed5cccac55d0548f46761707ece9", null ],
    [ "nc_tls_init", "db/db4/group__tls.html#ga9e011091a1e6ce205e58f4d9677a7e17", null ]
];