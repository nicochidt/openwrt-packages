var group__customds =
[
    [ "ncds_custom_funcs", "d0/d28/structncds__custom__funcs.html", [
      [ "copyconfig", "d0/d28/structncds__custom__funcs.html#ae0d54e97fa9abaafbf3b234c365a09b6", null ],
      [ "deleteconfig", "d0/d28/structncds__custom__funcs.html#a6318498a2d647313bf272303228ee4dc", null ],
      [ "editconfig", "d0/d28/structncds__custom__funcs.html#a218bd52cfd25ead58364f2d058dd737f", null ],
      [ "free", "d0/d28/structncds__custom__funcs.html#af147a5b35325a0d302af2d813e60df06", null ],
      [ "getconfig", "d0/d28/structncds__custom__funcs.html#a7e5c2e2b2abdd48a249f02526e04ceca", null ],
      [ "init", "d0/d28/structncds__custom__funcs.html#a8da4627756e752c849c155ed1c7a09db", null ],
      [ "is_locked", "d0/d28/structncds__custom__funcs.html#ae03c8955608bc2c438d9804d18f340b8", null ],
      [ "lock", "d0/d28/structncds__custom__funcs.html#ad4ec2f4e544216398bf5b56a383a4dfa", null ],
      [ "rollback", "d0/d28/structncds__custom__funcs.html#a1f69235dfc5cd8714c45690fff0abdc5", null ],
      [ "unlock", "d0/d28/structncds__custom__funcs.html#a5bb396eac30e2f060592465f1b8cb2a9", null ],
      [ "was_changed", "d0/d28/structncds__custom__funcs.html#a793b5d1b168db7d9529cbc6d02e614b1", null ]
    ] ],
    [ "ncds_custom_set_data", "da/d64/group__customds.html#ga1e9518d8cc9023c7585fd4de15daa75b", null ]
];