var searchData=
[
  ['init',['init',['../d0/d28/structncds__custom__funcs.html#a8da4627756e752c849c155ed1c7a09db',1,'ncds_custom_funcs::init()'],['../d9/dc0/structtransapi.html#a8cb29ceda55d20ecbec3784d536851db',1,'transapi::init()']]],
  ['is_5flocked',['is_locked',['../d0/d28/structncds__custom__funcs.html#ae03c8955608bc2c438d9804d18f340b8',1,'ncds_custom_funcs']]]
];
