var searchData=
[
  ['arg_5fcount',['arg_count',['../d0/df8/structtransapi__rpc__callbacks.html#ad4e017d16d393756e4e27927d06084ec',1,'transapi_rpc_callbacks']]],
  ['arg_5forder',['arg_order',['../d0/df8/structtransapi__rpc__callbacks.html#ae5d4a40ee77a8f12e0cb49f592719338',1,'transapi_rpc_callbacks']]]
];
