var searchData=
[
  ['xmldiff_5fop',['XMLDIFF_OP',['../d8/d55/group__transapi.html#ga10d59d84527f735d2781dbbb629a4488',1,'transapi.h']]]
];
