var searchData=
[
  ['url_20capability',['URL capability',['../d5/d7d/group__url.html',1,'']]]
];
