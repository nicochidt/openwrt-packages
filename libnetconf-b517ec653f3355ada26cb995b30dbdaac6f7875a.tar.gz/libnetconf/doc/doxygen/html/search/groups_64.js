var searchData=
[
  ['datastore_20operations',['Datastore operations',['../db/d67/group__store.html',1,'']]]
];
