var searchData=
[
  ['was_5fchanged',['was_changed',['../d0/d28/structncds__custom__funcs.html#a793b5d1b168db7d9529cbc6d02e614b1',1,'ncds_custom_funcs']]]
];
