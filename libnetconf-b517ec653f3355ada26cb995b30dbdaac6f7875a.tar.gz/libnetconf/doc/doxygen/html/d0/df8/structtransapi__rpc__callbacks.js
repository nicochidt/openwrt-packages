var structtransapi__rpc__callbacks =
[
    [ "arg_count", "d0/df8/structtransapi__rpc__callbacks.html#ad4e017d16d393756e4e27927d06084ec", null ],
    [ "arg_order", "d0/df8/structtransapi__rpc__callbacks.html#ae5d4a40ee77a8f12e0cb49f592719338", null ],
    [ "callbacks", "d0/df8/structtransapi__rpc__callbacks.html#a0ad28c1d0d3518ca0b3d631a20eaf48d", null ],
    [ "callbacks_count", "d0/df8/structtransapi__rpc__callbacks.html#a853d73f0f495147dba4842e9f860d1f0", null ],
    [ "func", "d0/df8/structtransapi__rpc__callbacks.html#a15569b8737513da9b760834a5e5be80c", null ],
    [ "name", "d0/df8/structtransapi__rpc__callbacks.html#a5ac083a645d964373f022d03df4849c8", null ]
];