var transport_8h =
[
    [ "NC_TRANSPORT", "d2/d02/transport_8h.html#ga8be6ccea205129b05c38331a7a42174a", [
      [ "NC_TRANSPORT_UNKNOWN", "d2/d02/transport_8h.html#gga8be6ccea205129b05c38331a7a42174aa914942ddb1fbb24a094f8e6ec5188e6e", null ],
      [ "NC_TRANSPORT_SSH", "d2/d02/transport_8h.html#gga8be6ccea205129b05c38331a7a42174aa7878cac9e93258d6bb1a2f166377606a", null ],
      [ "NC_TRANSPORT_TLS", "d2/d02/transport_8h.html#gga8be6ccea205129b05c38331a7a42174aa9dfde07fbf3ce02396167716ef70c612", null ]
    ] ],
    [ "nc_session_accept", "d2/d02/transport_8h.html#gad0e758dfee764ae9c2a032e0151c6707", null ],
    [ "nc_session_accept_username", "d2/d02/transport_8h.html#ga7ee207cac84fd5cd82419af41e14c06f", null ],
    [ "nc_session_connect", "d2/d02/transport_8h.html#gae3858d998d19cb2fb700b15fdf602f23", null ],
    [ "nc_session_connect_channel", "d2/d02/transport_8h.html#ga7d9e0f17bb4ca5b35c8343db59955060", null ],
    [ "nc_session_transport", "d2/d02/transport_8h.html#ga6e125c035cdebae8c49ff962866c0806", null ]
];