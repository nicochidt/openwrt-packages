var structtransapi__data__callbacks =
[
    [ "callbacks", "d6/dcb/structtransapi__data__callbacks.html#a37c3f849c79cfe4991c6d0a6526b12d7", null ],
    [ "callbacks_count", "d6/dcb/structtransapi__data__callbacks.html#a853d73f0f495147dba4842e9f860d1f0", null ],
    [ "data", "d6/dcb/structtransapi__data__callbacks.html#a735984d41155bc1032e09bece8f8d66d", null ]
];