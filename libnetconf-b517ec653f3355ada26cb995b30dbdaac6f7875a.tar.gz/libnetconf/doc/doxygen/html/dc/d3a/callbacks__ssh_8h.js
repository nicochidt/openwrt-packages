var callbacks__ssh_8h =
[
    [ "nc_callback_ssh_host_authenticity_check", "dc/d3a/callbacks__ssh_8h.html#ga9810aff5060e374925933d41913fbe5a", null ],
    [ "nc_callback_sshauth_interactive", "dc/d3a/callbacks__ssh_8h.html#gacb6042fe2f3cfe5d79e01de599c546eb", null ],
    [ "nc_callback_sshauth_passphrase", "dc/d3a/callbacks__ssh_8h.html#ga81ef9b1c1949bbffd86cbfd9aa159726", null ],
    [ "nc_callback_sshauth_password", "dc/d3a/callbacks__ssh_8h.html#ga28299d575ef4e234ed96bad5c4f086fb", null ],
    [ "nc_set_keypair_path", "dc/d3a/callbacks__ssh_8h.html#gab5beccc3acd15a5ad6499992e24fbe59", null ]
];