Foris controller diagnostics module
===================================
This is a diagnostics module for foris-controller

Requirements
============

* foris-controller
* diagnostics command present

Installation
============

	``python setup.py install``
