/*
 * gateway_default_handler.h
 *
 *  Created on: Jan 29, 2010
 *      Author: rogge
 */

#ifndef GATEWAY_DEFAULT_HANDLER_H_
#define GATEWAY_DEFAULT_HANDLER_H_

#ifdef __linux__

extern struct olsr_gw_handler gw_def_handler;

#endif /* __linux__ */
#endif /* GATEWAY_DEFAULT_HANDLER_H_ */
