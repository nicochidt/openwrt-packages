import os

print(os.getenv("HOME", "def"))
