#!/bin/sh 
. $srcdir/check_common.sh
test_clamd3 4
