while true; do rm -rf /tmp/test-gnunetd-*; make check || break; done
