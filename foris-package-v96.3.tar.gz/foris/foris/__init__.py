# this file is automatically updated when distutils are running the setup
__version__ = "unknown"
# variable used to enable some device-specific features
DEVICE_CUSTOMIZATION = "turris"  # should be either "turris" or "omnia"
