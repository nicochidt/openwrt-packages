# coding=utf-8

iso2 = 'pl'
iso3 = 'pol'

name = u'Polski'
