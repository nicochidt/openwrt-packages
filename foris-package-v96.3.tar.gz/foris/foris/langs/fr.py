# coding=utf-8

iso2 = 'fr'
iso3 = 'fra'

name = u'Français'
