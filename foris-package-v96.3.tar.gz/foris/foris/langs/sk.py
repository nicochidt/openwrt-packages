# coding=utf-8

iso2 = 'sk'
iso3 = 'svk'

name = u'Slovenčina'
