# coding=utf-8

iso2 = 'cs'
iso3 = 'cze'

name = u'Čeština'
