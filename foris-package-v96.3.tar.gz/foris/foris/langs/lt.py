# coding=utf-8

iso2 = 'lt'
iso3 = 'lit'

name = u'Lietuvių kalba'
