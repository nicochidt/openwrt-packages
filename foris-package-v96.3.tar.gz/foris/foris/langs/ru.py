# coding=utf-8

iso2 = 'ru'
iso3 = 'rus'

name = u'Русский'
