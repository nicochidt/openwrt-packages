# coding=utf-8

iso2 = 'de'
iso3 = 'deu'

name = u'Deutsch'
