# coding=utf-8

iso2 = 'da'
iso3 = 'dan'

name = u'Dansk'
