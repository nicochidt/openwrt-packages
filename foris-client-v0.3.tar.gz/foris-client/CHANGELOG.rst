0.3 (2017-09-06)
----------------

* raise an exception when an error message is recieved
* timeout option added

0.2.1 (2017-08-31)
------------------

* fix debug message prints in ubus

0.2 (2017-08-28)
----------------

* smoother ubus reconnect

0.1 (2017-08-11)
----------------

* initial version
