#ifndef LUA_XMLWRAP_H
#define LUA_XMLWRAP_H

#include <lua.h>

int xmlwrap_init(lua_State *L);

#endif /* LUA_XMLWRAP_H */
