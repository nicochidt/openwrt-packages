devdetect
========
Utility to detect newly connected devices

It uses pakond backend to get information about devices on local network. When unknown device appears, the notification is created.
