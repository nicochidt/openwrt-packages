require("mobdebug").loop() -- same as loop("localhost", 8172)
