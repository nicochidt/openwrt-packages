0.3 (2017-09-25)
----------------

* json definitions can be read from another directory list

0.2 (2017-08-28)
----------------

* json definitions added
* validate_verbose function
* schema validation improvements


0.1 (2017-08-01)
----------------

* initial version
