//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDS_DEF_HES_RHS                 1
#define IDS_DEF_HES_LHS                 2
#define IDS_DEF_HES_CONFIG_FILE         3
#define IDS_DEF_RESCONF_PATH            4
#define IDS_DEF_DNS1                    5
#define IDS_DEF_DNS2                    6
#define IDS_DEF_DNS3                    7
#define IDS_TCPIP_PATH_NT               8
#define IDS_TCPIP_PATH_95               9
#define IDS_NT_DOMAIN_KEY               10
#define IDS_NT_NS_KEY                   11
#define IDS_W95_DOMAIN_KEY              12
#define IDS_W95_NS_KEY                  13
#define IDS_TCPIP_PATH_NT_TRANSIENT     14

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
