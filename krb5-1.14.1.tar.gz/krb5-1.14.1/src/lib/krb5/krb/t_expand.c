/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil -*- */
#define TEST
#include "chk_trans.c"
