Luacheck documentation
======================

Contents:

.. toctree::

   warnings
   cli
   config
   inline
   module

This is documentation for 0.15.1 version of `Luacheck <https://github.com/mpeterv/luacheck/>`_, a linter for `Lua <http://www.lua.org/>`_.
