string = "foo"
table.append = table.insert
_ENV = nil
foo = "4"; print(foo)
bar = "5"; print(bar)
baz[4] = "6"; print(baz)
