print(setfenv(rawlen(tostring)))
