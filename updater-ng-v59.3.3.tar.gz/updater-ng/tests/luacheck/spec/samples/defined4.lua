function foo()
   foo = 1
   bar = {}
end
