#!/bin/sh
echo $SUCCESS > "$ROOT_DIR"/usr/share/postupdate_hook_ok
