#!/bin/sh
touch "$ROOT_DIR"/usr/share/preupdate_hook_ok
