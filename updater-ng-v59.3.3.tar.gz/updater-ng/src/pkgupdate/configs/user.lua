--[[
A place for user definitions.

Repository "name" "URI" { ca = "file:///etc/ssl/ca.pem", pubkey = "file:///etc/repo.pubkey" }
Install "pkgname" "other"
]]
