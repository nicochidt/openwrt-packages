# test handling of unicode chars in string % formatting

print('α' % ())
