# Check for emacs keys in REPL
t = +11
t == 2
