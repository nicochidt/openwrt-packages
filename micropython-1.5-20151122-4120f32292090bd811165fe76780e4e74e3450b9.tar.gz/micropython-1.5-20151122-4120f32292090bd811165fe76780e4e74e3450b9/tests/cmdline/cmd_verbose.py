# cmdline: -v -v
# test verbose output
print(1)
