# basic REPL tests
print(1)
[A
