import bench

def test(num):
    for i in iter(range(num)):
        pass

bench.run(test)
