x = list(range(10))
print(x[::-1])
print(x[::2])
print(x[::-2])

x = list(range(9))
print(x[::-1])
print(x[::2])
print(x[::-2])
