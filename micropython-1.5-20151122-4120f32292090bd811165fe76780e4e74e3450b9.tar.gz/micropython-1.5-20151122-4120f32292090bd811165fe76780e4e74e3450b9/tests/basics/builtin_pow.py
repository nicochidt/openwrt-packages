# test builtin pow() with integral values

# 2 arg version
print(pow(0, 1))
print(pow(1, 0))
print(pow(-2, 3))
print(pow(3, 8))

# 3 arg version
print(pow(3, 4, 7))

