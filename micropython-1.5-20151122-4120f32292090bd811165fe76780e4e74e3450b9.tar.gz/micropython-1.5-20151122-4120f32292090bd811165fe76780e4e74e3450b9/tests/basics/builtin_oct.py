# test builtin oct function

print(oct(1))
print(oct(-1))
print(oct(15))
print(oct(-15))

print(oct(12345))
print(oct(0o12345))

print(oct(12345678901234567890))
print(oct(0o12345670123456701234))
