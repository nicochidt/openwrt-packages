s = {1, 2, 3, 4}
print(s.add(5))
print(sorted(s))
