print(sorted({1}.union({2})))
