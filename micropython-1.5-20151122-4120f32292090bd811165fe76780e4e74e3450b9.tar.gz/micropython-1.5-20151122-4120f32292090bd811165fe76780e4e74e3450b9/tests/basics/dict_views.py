d = {1: 2}
for m in d.items, d.values, d.keys:
    print(m())
    print(list(m()))

# set operations still to come
