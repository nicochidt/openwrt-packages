char *prompt(char *p);
void prompt_read_history(void);
void prompt_write_history(void);
