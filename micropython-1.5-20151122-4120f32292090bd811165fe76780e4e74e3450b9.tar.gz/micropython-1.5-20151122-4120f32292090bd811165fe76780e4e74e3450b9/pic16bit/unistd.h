// XC16 compiler doesn't seem to have unistd.h file

#define SEEK_CUR 1
