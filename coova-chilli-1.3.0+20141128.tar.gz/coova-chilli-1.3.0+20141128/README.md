coova-chilli
============

CoovaChilli is an open-source software access controller for captive portal hotspots.
