#!/bin/sh
echo Content-Type: text/plain
echo

echo "{ \"v\":\"0.0.1\", \"s\":\"SESSION\" }"

