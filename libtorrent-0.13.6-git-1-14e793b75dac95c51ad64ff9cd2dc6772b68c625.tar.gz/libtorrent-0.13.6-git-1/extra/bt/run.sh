#!/bin/sh

for ((i = 0; i < 10; i++)); do bt.sh down$i ; done
