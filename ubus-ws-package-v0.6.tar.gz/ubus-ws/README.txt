Websocket server for ubus
=========================
