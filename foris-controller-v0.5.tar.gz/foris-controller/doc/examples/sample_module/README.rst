Foris controller sample module
==============================
This is a sample module for foris-controller

Requirements
============

* foris-controller

Installation
============

	``python setup.py install``
