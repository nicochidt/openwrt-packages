0.5 (2017-10-02)
----------------

* dns module (several option regarding dns)
* web module (language switch)
* wrapper around system services (start, stop, reload, ...)
* wrapper around uci command

0.4 (2017-09-06)
----------------

* docs updates
* put stack traces to error msgs
* write stack traces to debug console
* syslog integration

0.3 (2017-09-04)
----------------

* registration number call added
* contract valid call added
* router registered call added

0.2 (2017-08-23)
----------------

* --single argument for ubus
* making modules and backends modular
* locking moved to backends


0.1 (2017-08-07)
----------------

* initial version
