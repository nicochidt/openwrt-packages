Turris Firewall Rules
=====================

These scripts are used for downloading and applying firewall rules into Openwrt firewall environment.

They are used as a part of the Turris project (see http://www.turris.cz).
