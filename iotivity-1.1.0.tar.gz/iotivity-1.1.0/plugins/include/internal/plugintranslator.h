// This file will host the translate TO "zigbee" or "zwave" functions
