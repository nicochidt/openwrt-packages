Title of Sub-Project: "Plugin Interface" or "PI" for short.

Descriptions:

  include: The source code include files (*.h). Please use the
           plugininterface.h file to access the APIs for this
           sub-project "Plugin Interface".

  samples: The consumer of IoTivity & Plugin Interface APIs.

  src: The source files.

  zigbee_wrapper: This contains an abstraction shim layer to encapsulate our
                  use case for the zigbee-library (ie. the one pulled in to
                  extlibs directory above).
